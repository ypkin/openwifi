# openwrt-mt7610e
MTK Driver ported to OpenWRT
