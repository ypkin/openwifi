/*
	Network Acceleration related function
*/

#include "rt_config.h"



